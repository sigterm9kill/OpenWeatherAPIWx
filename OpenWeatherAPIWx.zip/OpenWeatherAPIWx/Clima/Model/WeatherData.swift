//
//  WeatherData.swift
//  Climate Check
//
//  Created by Sean O'Brien on 02/11/2020.
//  Copyright © 2020 Sean O'Brien. All rights reserved.
//
import Foundation

struct WeatherData: Codable {
    let name: String
    let main: Main
    let weather: [Weather]
}

struct Main: Codable {
    let temp: Double
}

struct Weather: Codable {
    let description: String
    let id: Int
}
